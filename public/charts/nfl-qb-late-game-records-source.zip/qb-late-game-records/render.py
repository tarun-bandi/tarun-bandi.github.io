import argparse
import csv
import os
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

PAPER, INK, MUTED = '#fbf9f3', '#20281f', '#50614f'
ACCENT, LINE, GRID = '#2f5944', '#d0d6c8', '#e0e3d8'
FONT_DIR = Path(os.environ.get('CHART_FONT_DIR', '/usr/share/fonts/truetype/dejavu'))
LOGO_SLUGS = {'LA': 'lar', 'WAS': 'wsh'}


def font(name, size):
    return ImageFont.truetype(str(FONT_DIR / f'DejaVu{name}.ttf'), size)


def record(row, keys):
    wins, losses, ties = (int(row[key]) for key in keys)
    values = [wins, losses, ties] if ties else [wins, losses]
    return '–'.join(map(str, values)) if wins + losses + ties else '—'


def render(records, logos, output):
    with records.open() as f:
        quarterbacks = list(csv.DictReader(f))

    width, row_height, top = 1280, 48, 297
    bottom = top + row_height * len(quarterbacks)
    image = Image.new('RGB', (width, bottom + 148), PAPER)
    draw = ImageDraw.Draw(image)
    small = font('Sans', 18)
    bold_small = font('Sans-Bold', 18)
    name_font = font('Sans-Bold', 24)
    record_font = font('Sans', 23)

    def label(x, y, message, face=small, color=INK, anchor='lm'):
        draw.text((x, y), message, font=face, fill=color, anchor=anchor)

    def rule(y, color=LINE, stroke=1):
        draw.line((48, y, 1232, y), fill=color, width=stroke)

    def bar_x(pct):
        return 388 + pct * 980

    label(49, 44, 'NFL QUARTERBACKS', bold_small, ACCENT)
    label(1231, 44, 'THROUGH WEEK 10 · 2026', bold_small, ACCENT, 'rm')
    rule(67)
    label(47, 122, 'Down in the final eight', font('Serif', 69))
    label(50, 186, 'How often starting QBs win after trailing in the final eight minutes of regulation',
          font('Sans', 23), MUTED)

    label(106, 246, 'QUARTERBACK', bold_small, MUTED)
    label(388, 246, 'CAREER WIN %', bold_small, MUTED)
    label(1006, 246, 'CAREER W–L–T', bold_small, MUTED, 'mm')
    label(1160, 246, '2026 W–L–T', bold_small, MUTED, 'mm')

    for tick in (0.0, 0.1, 0.2, 0.3, 0.4):
        x = bar_x(tick)
        label(x, 277, f'{tick:.0%}', small, MUTED, 'mm')
        draw.line((x, top, x, bottom), fill=GRID)
    rule(top, stroke=2)

    for i, row in enumerate(quarterbacks):
        y = top + row_height * i + row_height // 2
        team = row['team']
        slug = LOGO_SLUGS.get(team, team.lower())
        with Image.open(logos / f'{slug}.png') as file:
            logo = file.convert('RGBA')
        logo = logo.crop(logo.getchannel('A').getbbox())
        logo.thumbnail((44, 35), Image.Resampling.LANCZOS)
        image.paste(logo, (71 - logo.width // 2, y - logo.height // 2), logo)
        label(106, y, row['name'], name_font)

        pct = float(row['pct'])
        end = bar_x(pct)
        if pct:
            draw.rounded_rectangle((bar_x(0), y - 7, end, y + 7), radius=3, fill=ACCENT)
        else:
            draw.ellipse((end - 3, y - 3, end + 3, y + 3), fill=ACCENT)
        label(end + 12, y, f'{pct:.1%}', bold_small, ACCENT)
        label(1006, y, record(row, ('wins', 'losses', 'ties')), record_font, INK, 'mm')
        label(1160, y, record(row, ('w26', 'l26', 't26')), record_font, MUTED, 'mm')
        rule(y + row_height // 2, GRID)

    rule(bottom, stroke=2)
    label(50, bottom + 37, 'Week 11 starters with 16+ career regular-season starts. Logos show current teams.', small, MUTED)
    label(50, bottom + 67, 'Career includes playoffs. Ties count as half a win. Records use the final score, including overtime.', small, MUTED)
    label(50, bottom + 105, 'Play-by-play and schedules: nflverse  ·  Team logos: ESPN', bold_small, ACCENT)

    output.parent.mkdir(exist_ok=True, parents=True)
    image.save(output, optimize=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--records', type=Path, default=Path('records.csv'))
    parser.add_argument('--logos', type=Path, default=Path('data/logos'))
    parser.add_argument('--output', type=Path, default=Path('nfl-qb-late-game-records.png'))
    args = parser.parse_args()
    render(args.records, args.logos, args.output)
