"""Read the nflverse game and play-by-play files and flag qualifying team-games."""

from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq

ROOT = Path('data')
cols = ['game_id', 'qtr', 'quarter_seconds_remaining', 'play_id', 'posteam', 'posteam_type',
        'posteam_score', 'defteam_score', 'total_home_score', 'total_away_score',
        'passer_id', 'passer', 'desc', 'home_score', 'away_score']
games = pd.read_csv(ROOT/'games.csv', low_memory=False)
games = games.loc[games.season.ge(2008) & games.gameday.le('2026-11-18') & games.home_score.notna()].copy()
sides = []
for team, other in [('home', 'away'), ('away', 'home')]:
    sides.append(pd.DataFrame({
        'game_id': games.game_id, 'season': games.season, 'week': games.week,
        'game_type': games.game_type, 'gameday': games.gameday, 'side': team,
        'team': games[team+'_team'], 'opponent': games[other+'_team'],
        'qb_id': games[team+'_qb_id'], 'qb_name': games[team+'_qb_name'],
        'margin': games[team+'_score']-games[other+'_score'],
    }))
starts = pd.concat(sides, ignore_index=True)
assert starts.qb_id.notna().all()
assert not starts.duplicated(['game_id', 'side']).any()
pieces = []
passers = []
for season in range(2008, 2027):
    file = ROOT / f'pbp{season}.parquet'
    p = pq.read_table(file, columns=cols).to_pandas()
    p = p[p.game_id.isin(games.game_id)]
    expected = set(games.loc[games.season.eq(season), 'game_id'])
    assert set(p.game_id) == expected, (season, expected - set(p.game_id), set(p.game_id)-expected)
    scores = p.groupby('game_id')[['home_score','away_score']].last()
    expected_scores = games.set_index('game_id').loc[scores.index, ['home_score','away_score']]
    assert scores.astype(float).equals(expected_scores.astype(float)), season
    p['post_margin'] = p.total_home_score - p.total_away_score
    p['pre_margin'] = p.groupby('game_id').post_margin.shift()
    window = p[p.qtr.eq(4) & p.quarter_seconds_remaining.gt(0) & p.quarter_seconds_remaining.le(480)].copy()
    score_check = (window.posteam_score - window.defteam_score).where(
        window.posteam_type.eq('home'), window.defteam_score - window.posteam_score
    )
    primary = score_check.combine_first(window.pre_margin)
    bounds = primary.groupby(window.game_id).agg(['min', 'max'])
    alternate = window.pre_margin.groupby(window.game_id).agg(['min', 'max'])
    cases = bounds.index[(bounds['min'].lt(0) != alternate['min'].lt(0)) |
                         (bounds['max'].gt(0) != alternate['max'].gt(0))]
    if len(cases):
        print(f'{season}: review score discrepancies in {list(cases)}')
    assert set(bounds.index) == expected, (season, 'no Q4 plays')
    pieces.append(pd.concat([bounds['min'].lt(0).rename('trailed').to_frame().assign(side='home'),
                             bounds['max'].gt(0).rename('trailed').to_frame().assign(side='away')]))
    first = p[p.passer_id.notna() & p.posteam.notna()].drop_duplicates(['game_id','posteam'])
    passers.append(first[['game_id','posteam','passer_id','passer','desc']])
first_pass = pd.concat(passers).rename(columns={'posteam': 'team'})
starts = starts.merge(first_pass, on=['game_id', 'team'], how='left', validate='one_to_one')
starts = starts.merge(pd.concat(pieces).reset_index(), on=['game_id', 'side'], validate='one_to_one')
starts.to_csv(ROOT / 'game_sides.csv', index=False)
