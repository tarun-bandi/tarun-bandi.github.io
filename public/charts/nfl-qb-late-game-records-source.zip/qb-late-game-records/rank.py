"""Resolve starting quarterbacks and calculate career and season records."""

import pandas as pd

CANDIDATES = {
    'ARI': 'Carson Beck', 'ATL': 'Michael Penix Jr.', 'BAL': 'Jacoby Brissett',
    'BUF': 'Josh Allen', 'CAR': 'Bryce Young', 'CHI': 'Caleb Williams', 'CIN': 'Joe Burrow',
    'CLE': 'Deshaun Watson', 'DAL': 'Dak Prescott', 'DEN': 'Bo Nix', 'DET': 'Jared Goff',
    'GB': 'Jordan Love', 'HOU': 'C.J. Stroud', 'IND': 'Daniel Jones',
    'JAX': 'Trevor Lawrence', 'KC': 'Patrick Mahomes', 'LA': 'Matthew Stafford',
    'LAC': 'Justin Herbert', 'LV': 'Fernando Mendoza', 'MIA': 'Kyle McCord',
    'MIN': 'Kirk Cousins', 'NE': 'Drake Maye', 'NO': 'Tyler Shough', 'NYG': 'J.J. McCarthy',
    'NYJ': 'Geno Smith', 'PHI': 'Joe Milton III', 'PIT': 'Aaron Rodgers', 'SEA': 'Sam Darnold',
    'SF': 'Brock Purdy', 'TB': 'Baker Mayfield', 'TEN': 'Cam Ward', 'WAS': 'Jayden Daniels',
}

starts = pd.read_csv('data/game_sides.csv')
ids = starts.drop_duplicates('qb_name').set_index('qb_name').qb_id.to_dict()
ids['Carson Beck'] = '00-0041561'

# Correct stale schedule labels using the opening QB in the game log.
corrections = {
    '2016_17_DAL_PHI:DAL': 'Dak Prescott',
    '2018_17_DET_GB:GB': 'Aaron Rodgers',
    '2019_17_NYJ_BUF:BUF': 'Josh Allen',
    '2021_16_TB_CAR:CAR': 'Cam Newton',
    '2022_11_CAR_BAL:CAR': 'Baker Mayfield',
    '2024_10_NYG_CAR:CAR': 'Bryce Young',
    '2024_12_KC_CAR:CAR': 'Bryce Young',
    '2024_13_TB_CAR:CAR': 'Bryce Young',
    '2024_14_CAR_PHI:CAR': 'Bryce Young',
    '2024_09_WAS_NYG:WAS': 'Jayden Daniels',
    '2024_10_PIT_WAS:WAS': 'Jayden Daniels',
    '2024_11_WAS_PHI:WAS': 'Jayden Daniels',
    '2024_12_DAL_WAS:WAS': 'Jayden Daniels',
    '2024_13_TEN_WAS:WAS': 'Jayden Daniels',
    '2024_18_BUF_NE:NE': 'Drake Maye',
    '2024_18_HOU_TEN:HOU': 'C.J. Stroud',
    '2025_08_BUF_CAR:CAR': 'Andy Dalton',
    '2025_04_WAS_ATL:WAS': 'Marcus Mariota',
    '2025_08_WAS_KC:WAS': 'Marcus Mariota',
    '2025_14_WAS_MIN:WAS': 'Jayden Daniels',
    '2026_02_CAR_ATL:ATL': 'Cooper Rush',
    '2026_03_SEA_WAS:WAS': 'Marcus Mariota',
    '2026_03_SEA_WAS:SEA': 'Sam Darnold',
    '2026_04_NYJ_CHI:CHI': 'Tyson Bagent',
    '2026_04_LAC_SEA:SEA': 'Sam Darnold',
    '2026_05_SF_SEA:SEA': 'Sam Darnold',
    '2026_06_SEA_DEN:SEA': 'Sam Darnold',
    '2026_07_DAL_PHI:PHI': 'Tanner McKee',
    '2026_10_LA_ARI:ARI': 'Carson Beck',
    '2026_10_LAC_BAL:BAL': 'Jacoby Brissett',
    '2026_10_SEA_LV:SEA': 'Drew Lock',
}
starts['key'] = starts.game_id + ':' + starts.team
for key, name in corrections.items():
    mask = starts.key.eq(key)
    assert mask.sum() == 1
    starts.loc[mask, 'qb_name'] = name
    starts.loc[mask, 'qb_id'] = ids[name]
    assert starts.loc[mask, 'passer_id'].item() == ids[name], key

starts['outcome'] = starts.margin.map(lambda margin: 'W' if margin > 0 else 'L' if margin < 0 else 'T')

def record(games):
    return tuple(int(games.outcome.eq(x).sum()) for x in 'WLT')

rows = []
for team, name in CANDIDATES.items():
    games = starts[starts.qb_id.eq(ids[name])]
    n = int(games.game_type.eq('REG').sum())
    late = games[games.trailed]
    w, l, t = record(late)
    sw, sl, st = record(late[late.season.eq(2026)])
    rows.append(dict(name=name, team=team, starts=n, wins=w, losses=l, ties=t,
                     pct=(w+0.5*t)/(w+l+t) if w+l+t else 0, w26=sw, l26=sl, t26=st))
ranks = pd.DataFrame(rows).sort_values(['pct','wins','name'], ascending=[False,False,True])
print(ranks.to_string(index=False, formatters={'pct': '{:.2%}'.format}))
ranks.query('starts >= 16').to_csv('records.csv', index=False)
