"""Download the nflverse data and team logos used for this chart."""

import argparse
import shutil
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

LOGOS = 'atl bal buf car chi cin cle dal den det gb hou ind jax kc lac lar min ne no nyj pit sea sf tb ten wsh'.split()
PBP = 'https://github.com/nflverse/nflverse-data/releases/download/pbp'
SCHEDULE = 'https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv'
ESPN = 'https://a.espncdn.com/i/teamlogos/nfl/500'

def download(pair):
    url, path = pair
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix('.part')
    with urllib.request.urlopen(url, timeout=120) as response, partial.open('wb') as file:
        shutil.copyfileobj(response, file)
    partial.replace(path)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--logos-only', action='store_true')
    args = parser.parse_args()
    root = Path('data')
    downloads = [(f'{ESPN}/{code}.png', root / 'logos' / f'{code}.png') for code in LOGOS]
    if not args.logos_only:
        downloads.append((SCHEDULE, root / 'games.csv'))
        downloads.extend((f'{PBP}/play_by_play_{year}.parquet', root / f'pbp{year}.parquet')
                         for year in range(2008, 2027))
    with ThreadPoolExecutor(max_workers=6) as executor:
        list(executor.map(download, downloads))
