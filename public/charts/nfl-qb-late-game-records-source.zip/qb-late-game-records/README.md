# NFL QB records when trailing in the final eight minutes

Published on [Tarun Bandi’s Sports Charts](https://tarun-bandi.github.io/#nfl-qb-late-game-records). The chart covers 2026 Week 11 starters with at least 16 career regular-season starts, using results through Week 10.

A game qualifies when the team is down before a play or at another recorded score observation with 8:00 or less and time remaining in the fourth quarter. The result goes to the quarterback who started the game. Career numbers include playoffs and work across previous teams. Overtime counts in the final outcome, and a tie counts as half a win. The team logo reflects the Week 11 depth chart.

## Render the published chart

Use Python 3.12 and DejaVu fonts. Set `CHART_FONT_DIR` if the fonts live somewhere other than `/usr/share/fonts/truetype/dejavu`.

```sh
python -m pip install -r requirements.txt
python download.py --logos-only
python render.py
```

`records.csv` contains the published results, so the rendering step only needs the team logos. To recalculate the records from the upstream play-by-play and schedule files:

```sh
python download.py
python extract.py
python rank.py
python render.py
```

The source datasets may receive corrections after publication. The calculation checks that play-by-play coverage and final scores agree with the schedule, and `rank.py` documents corrections to stale starter labels. The checked-in CSV preserves the values used for publication.

Data comes from [nflverse play-by-play](https://github.com/nflverse/nflverse-data/releases/tag/pbp) and the [nflverse schedule](https://github.com/nflverse/nfldata). The Week 11 starter list comes from [Lineup Field](https://lineupfield.com/starting-quarterbacks/). Team logos are from ESPN.
